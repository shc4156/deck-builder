'use client';
import { useState, useEffect } from 'react';
import { supabase } from '../../lib/supabaseClient';
import PageLayout from '../../components/PageLayout';

export default function UploadGeneralPage() {
  const [generals, setGenerals] = useState([]);
  const [imageFiles, setImageFiles] = useState([]);
  const [results, setResults] = useState([]);
  const [isUploading, setIsUploading] = useState(false);

  useEffect(() => {
    async function loadGenerals() {
      const { data } = await supabase
        .from('generals')
        .select('id, name')
        .order('name', { ascending: true });
      if (data) setGenerals(data);
    }
    loadGenerals();
  }, []);

  // 파일 하나를 크롭해서 blob으로 반환 (장수 카드 비율: 800x700)
  async function cropImage(file) {
    const img = new Image();
    img.src = URL.createObjectURL(file);
    await new Promise(r => img.onload = r);

    const canvas = document.createElement('canvas');
    canvas.width = 800;
    canvas.height = 700;
    const ctx = canvas.getContext('2d');

    const cropWidth = img.width * 0.55;
    const sx = img.width * 0.05;
    const cropHeight = cropWidth * (700 / 800);
    const sy = img.height * 0.10;

    ctx.drawImage(img, sx, sy, cropWidth, cropHeight, 0, 0, 800, 700);
    return await new Promise(r => canvas.toBlob(r, 'image/png'));
  }

  function getNameFromFile(file) {
    return file.name.replace(/\.[^/.]+$/, '').trim();
  }

  async function handleBulkUpload() {
    if (imageFiles.length === 0) return alert('이미지 파일을 선택하세요.');
    setIsUploading(true);
    setResults([]);

    for (const file of imageFiles) {
      const fileName = getNameFromFile(file);
      const matched = generals.find(g => g.name === fileName);

      if (!matched) {
        setResults(prev => [...prev, { file: file.name, status: 'unmatched', message: `"${fileName}"와 일치하는 장수를 찾을 수 없음` }]);
        continue;
      }

      try {
        const blob = await cropImage(file);
        const storageFileName = `general_${Date.now()}_${matched.id}.png`;

        const { error: uploadError } = await supabase.storage
          .from('generals')
          .upload(storageFileName, blob, { cacheControl: '3600', upsert: true });

        if (uploadError) {
          setResults(prev => [...prev, { file: file.name, status: 'error', message: '업로드 실패: ' + uploadError.message }]);
          continue;
        }

        const { data: publicData } = supabase.storage.from('generals').getPublicUrl(storageFileName);

        const { error: updateError } = await supabase
          .from('generals')
          .update({ image_url: publicData.publicUrl })
          .eq('id', matched.id);

        if (updateError) {
          setResults(prev => [...prev, { file: file.name, status: 'error', message: 'DB 업데이트 실패: ' + updateError.message }]);
          continue;
        }

        setResults(prev => [...prev, { file: file.name, status: 'success', message: `"${matched.name}" 등록 완료` }]);
      } catch (e) {
        setResults(prev => [...prev, { file: file.name, status: 'error', message: '처리 중 오류: ' + e.message }]);
      }
    }

    setIsUploading(false);
  }

  return (
    <PageLayout>
      <div style={{ padding: '40px' }}>
        <h1 className="classic-heading text-2xl font-bold">장수 이미지 일괄 업로드</h1>
        <p style={{ color: 'var(--text-secondary)', fontSize: '0.9rem' }}>
          파일명이 장수 이름과 정확히 일치해야 합니다 (예: 관우.png)
        </p>

        <input
          type="file"
          accept="image/*"
          multiple
          onChange={(e) => setImageFiles(Array.from(e.target.files))}
        />
        <p style={{ fontSize: '0.85rem', color: 'var(--text-muted)' }}>{imageFiles.length}개 파일 선택됨</p>

        <br />
        <button
          className="seal-button"
          onClick={handleBulkUpload}
          disabled={isUploading}
          style={{ padding: '10px 20px', cursor: isUploading ? 'not-allowed' : 'pointer' }}
        >
          {isUploading ? '업로드 중...' : '일괄 업로드 시작'}
        </button>

        {results.length > 0 && (
          <div style={{ marginTop: '30px', maxWidth: '600px' }}>
            <h3 style={{ color: 'var(--text-primary)' }}>진행 결과 ({results.filter(r => r.status === 'success').length}/{results.length} 성공)</h3>
            <ul style={{ listStyle: 'none', padding: 0 }}>
              {results.map((r, i) => (
                <li key={i} style={{
                  padding: '8px 12px', marginBottom: '4px', borderRadius: '4px',
                  backgroundColor: r.status === 'success' ? 'rgba(78,154,99,0.15)' : r.status === 'unmatched' ? 'rgba(184,135,58,0.15)' : 'rgba(192,69,61,0.15)',
                  color: 'var(--text-primary)',
                  fontSize: '0.9rem'
                }}>
                  <strong>{r.file}</strong>: {r.message}
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>
    </PageLayout>
  );
}