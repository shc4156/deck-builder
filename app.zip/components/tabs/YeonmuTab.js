'use client';
import { useState, useMemo, useEffect } from 'react';
import { useDeckAssets } from '../../../hooks/useDeckAssets';
import { useYeonmuStorage } from '../../../hooks/useYeonmuStorage';
import { scoreTierDeckMatch } from '../../../data/tierDeckMatch';

/* ============================================================
   🎨 SquadsTab.js와 동일한 다크 오퍼레이션 테마 색상 상수
   (mockup_dark_formation.html 기준 — 값이 바뀌면 두 파일 모두 맞춰줘야 함)
============================================================ */
const SCROLL = {
  bg: '#0B0D11',
  paperLight: '#14171D',
  paperMid: '#1C2027',
  ink: '#EDEDED',
  inkFaint: '#8A8F98',
  border: '#3A3F4A',
  headerBorder: '#2A2E36',
  gold: '#B8873A',
  sealDark: '#C0453D',
  blue: '#3A7BC8',
  green: '#4E9A63',
  greenBg: '#1F2A22',
  greenSoft: '#8FBF9D',
  mono: 'var(--font-mono, ui-monospace, SFMono-Regular, "SF Mono", Menlo, monospace)',
};

const WAREHOUSE_LIMITS = {
  generals: 10,
  tactics: 20,
  supportTactics: 3,
};

const STEPS = [
  { key: 'generals', label: '1. 무장' },
  { key: 'tactics', label: '2. 전법' },
  { key: 'support', label: '3. 지원' },
  { key: 'decks', label: '4. 추천덱' },
];

// 🆕 장수 단계 진영 필터 목록
const FACTIONS = ['전체', '위', '촉', '오', '군'];

/* ============================================================
   🆕 지원 무장/전법 추천 점수 로직
   — SquadsTab.js의 ROLE_LABEL_MAP / ROLE_GROUP_MAP / getTierBadge /
     getTacticGradeBadge 와 동일한 값 사용 (값이 바뀌면 두 파일 모두 맞춰줘야 함)
============================================================ */
const ROLE_LABEL_MAP = {
  '방어_자신': '탱커', '방어_아군': '탱커',
  '딜_병기': '딜러', '딜_책략': '딜러', '딜_혼합': '딜러',
  '추격': '딜러(추격)', '액티브': '딜러(액티브)', '회심': '딜러(회심)',
  '힐': '힐러',
  '버프_자신': '버퍼', '버프_아군': '버퍼', '지원_복합': '버퍼',
  '디버프': '디버퍼',
};

const ROLE_GROUP_MAP = {
  '방어_자신': '탱', '방어_아군': '탱',
  '딜_병기': '딜', '딜_책략': '딜', '딜_혼합': '딜', '추격': '딜', '액티브': '딜', '회심': '딜',
  '힐': '힐',
  '버프_자신': '버프', '버프_아군': '버프', '지원_복합': '버프',
  '디버프': '디버프',
};

// 전법 효과 텍스트에서 겹침/보강 여부를 판단할 때 쓰는 키워드 (SquadsTab의 getTacticSimilarityScore와 동일)
const TACTIC_EFFECT_KEYWORDS = ['책략 피해', '병기 피해', '회복', '방어', '공포', '요술', '무장 해제', '능력 소진', '간파', '관통'];

// 점수 구간별 등급 배지 (S/A/B/C)
const getTierBadge = (score) => {
  const s = Number(score) || 0;
  if (s >= 90) return { label: 'S', color: SCROLL.sealDark };
  if (s >= 75) return { label: 'A', color: SCROLL.gold };
  if (s >= 60) return { label: 'B', color: SCROLL.blue };
  return { label: 'C', color: SCROLL.inkFaint };
};

// 전법 등급(보라/황금) 배지
const getTacticGradeBadge = (grade) => {
  if (!grade) return '';
  const g = String(grade).trim();
  if (g.includes('보라')) return '🟣';
  if (g.includes('황금')) return '🟡';
  return '';
};

// 지원 무장 후보 1명에 대한 추천 점수 + 이유
// - 창고에 이미 담긴 역할군(탱/딜/힐/버프/디버프)에 없는 역할을 채워주는지
// - 창고 무장과 세력이 겹쳐 세력 보너스에 기여하는지
// - 병종이 겹치지 않아 다양화에 도움이 되는지
// - 창고 무장과 인연(connections)이 있는지
const scoreSupportGeneral = (candidate, warehouseGeneralNames, allGenerals, connections) => {
  const warehouseGens = (warehouseGeneralNames || [])
    .map((n) => allGenerals.find((g) => g.name === n))
    .filter(Boolean);

  let score = 50;
  const reasons = [];

  const existingRoleGroups = warehouseGens.map((o) => ROLE_GROUP_MAP[o.preferred_tactic_type]).filter(Boolean);
  const roleCounts = existingRoleGroups.reduce((m, r) => { m[r] = (m[r] || 0) + 1; return m; }, {});
  const candRole = ROLE_GROUP_MAP[candidate.preferred_tactic_type];
  const candRoleLabel = ROLE_LABEL_MAP[candidate.preferred_tactic_type] || candRole;

  if (candRole) {
    if (!roleCounts[candRole]) {
      score += 25;
      reasons.push(`창고에 없는 ${candRoleLabel} 역할 보완`);
    } else if (roleCounts[candRole] === 1) {
      score += 8;
      reasons.push(`${candRoleLabel} 역할 백업`);
    }
  }

  const sameFactionCount = warehouseGens.filter((o) => o.faction && o.faction === candidate.faction).length;
  if (candidate.faction && sameFactionCount > 0) {
    score += Math.min(15, sameFactionCount * 6);
    reasons.push(`${candidate.faction} 세력 ${sameFactionCount}명과 소속 일치 (세력 보너스)`);
  }

  const sameTroopCount = warehouseGens.filter((o) => o.troop_type && o.troop_type === candidate.troop_type).length;
  if (candidate.troop_type && sameTroopCount === 0 && warehouseGens.length > 0) {
    score += 10;
    reasons.push(`${candidate.troop_type} 병종 다양화`);
  }

  if (connections && connections.length > 0 && warehouseGeneralNames && warehouseGeneralNames.length > 0) {
    const candName = candidate.name?.trim();
    const hasConn = connections.some((conn) => {
      const leader = conn.leader_name?.trim();
      const follower = conn.follower_name?.trim();
      return warehouseGeneralNames.some((heroName) => {
        const h = heroName?.trim();
        if (!h || h === candName) return false;
        return (leader === h && follower === candName) || (leader === candName && follower === h);
      });
    });
    if (hasConn) {
      score += 15;
      reasons.push('창고 무장과 인연 관계');
    }
  }

  return { score: Math.max(0, Math.min(100, Math.round(score))), reasons };
};

// 지원 전법 후보 1개에 대한 추천 점수 + 이유
// - 등급(보라/황금)이 높은지
// - 창고 전법들이 아직 다루지 않는 효과 키워드를 새로 보강해주는지
const scoreSupportTactic = (candidate, warehouseTacticNames, allTactics) => {
  let score = 50;
  const reasons = [];

  const grade = String(candidate.grade || '').trim();
  if (grade.includes('보라')) {
    score += 20;
    reasons.push('보라 등급 전법');
  } else if (grade.includes('황금')) {
    score += 10;
    reasons.push('황금 등급 전법');
  }

  const warehouseTacs = (warehouseTacticNames || [])
    .map((n) => allTactics.find((t) => t.name === n))
    .filter(Boolean);

  const coveredKeywords = new Set();
  warehouseTacs.forEach((wt) => {
    TACTIC_EFFECT_KEYWORDS.forEach((kw) => {
      if ((wt.effect || '').includes(kw)) coveredKeywords.add(kw);
    });
  });

  const candEffect = candidate.effect || '';
  const newKeywords = TACTIC_EFFECT_KEYWORDS.filter((kw) => candEffect.includes(kw) && !coveredKeywords.has(kw));
  if (newKeywords.length > 0) {
    score += 15;
    reasons.push(`${newKeywords.join('/')} 효과 보강`);
  }

  return { score: Math.max(0, Math.min(100, Math.round(score))), reasons };
};

/* ============================================================
   🆕 창고(+지원) 장수·전법 풀만으로 3개 부대(1부대 3명) 추천 편성
   — 1순위: 실제로 검증된 티어덱(장수 3명 전원 보유)을 장수가 안 겹치는 선에서
     최우선으로 그대로 배치(전법도 티어덱 원본 그대로 사용).
   — 2순위: 티어덱으로 못 채운 나머지 자리만, 남은 장수/전법 풀로 기존 휴리스틱
     greedy 배정을 적용해 빈 슬롯 없이 채운다.
============================================================ */
const YEONMU_SQUAD_COUNT = 3;
const YEONMU_SQUAD_SIZE = 3;

// 부대 편성 시 역할을 배정하는 우선순위 — 탱/힐처럼 희소한 역할부터 각 부대에 고르게 분산
const ROLE_PRIORITY = ['탱', '힐', '디버프', '버프', '딜'];

// PDF(연무대회 기본 로직 설명) 기준: 발동 확률이 낮고 편차가 큰 "확률형" 무장은 연무에서 페널티.
// 커뮤니티 가이드에 명시적으로 예시로 언급된 이름만 보수적으로 반영(DB에 발동확률 컬럼이 없어 하드코딩).
const YEONMU_VOLATILE_GENERALS = ['장각', '곽가'];

// 연무대회는 병법/장비 보너스가 없어 "퍼센트 피해 증가"보다 "고정 수치 피해 증가"가 더 유리하다는
// PDF 가이드를 반영한 키워드 — 전법 효과 텍스트에 이 표현이 있으면 가산점.
const FIXED_DAMAGE_KEYWORDS = ['고정 피해', '고정 수치', '추가 피해'];
const PERCENT_DAMAGE_KEYWORDS = ['피해 증가', '피해량 증가'];

// 전법 1개가 장수 1명에게 얼마나 궁합이 맞는지 점수화.
// 궁합이 전혀 없어도 최소 점수(30점)는 주기 때문에, 남는 전법이라도 반드시 배정될 수 있다.
const scoreTacticForGeneral = (tactic, general) => {
  let score = 30;
  const reasons = [];
  let typeMatched = false;

  const role = general.preferred_tactic_type || general.primary_role || '';
  const mainStat = general.main_stat || general.stat_focus || '';
  const effect = tactic.effect || '';
  const grade = String(tactic.grade || '').trim();

  if (role.includes('책략') && effect.includes('책략 피해')) { score += 30; reasons.push('책략형 궁합'); typeMatched = true; }
  if (role.includes('병기') && effect.includes('병기 피해')) { score += 30; reasons.push('병기형 궁합'); typeMatched = true; }
  if (role.includes('힐') && effect.includes('회복')) { score += 30; reasons.push('회복 궁합'); typeMatched = true; }
  if ((role.includes('방어') || role.includes('탱')) && effect.includes('방어')) { score += 25; reasons.push('방어 궁합'); typeMatched = true; }
  if (role.includes('디버프') && (effect.includes('공포') || effect.includes('무장 해제') || effect.includes('능력 소진') || effect.includes('간파'))) {
    score += 25; reasons.push('디버프 궁합'); typeMatched = true;
  }
  if (role.includes('버프') && !typeMatched && (effect.includes('증가') || effect.includes('회복'))) {
    score += 15; reasons.push('버프 계열'); typeMatched = true;
  }

  if (mainStat.includes('무력') && effect.includes('병기 피해')) score += 8;
  if (mainStat.includes('지력') && effect.includes('책략 피해')) score += 8;

  if (grade.includes('보라')) { score += 12; reasons.push('보라 등급'); }
  else if (grade.includes('황금')) { score += 6; reasons.push('황금 등급'); }

  // 🆕 연무대회 전용 가산점: 병법 시스템이 없어 전법 자체의 "고정 수치 피해" 효과가 더 유리(PDF 가이드 반영)
  if (FIXED_DAMAGE_KEYWORDS.some((kw) => effect.includes(kw))) {
    score += 10; reasons.push('연무 특화(고정 피해)');
  }

  if (!typeMatched) reasons.push('타입 불일치 · 대체 배정');

  return { score: Math.max(0, Math.round(score)), reasons, typeMatched };
};

// 창고(+지원) 장수/전법 풀에서, 이미 티어덱으로 선점된 이름을 제외한 "나머지"만으로
// 남은 부대 슬롯을 채운다. usedGeneralNames/usedTacticNames는 앞서 티어덱이 이미 사용한 이름들.
const buildRecommendedYeonmuSquads = (
  generalNames,
  tacticNames,
  allGenerals,
  allTactics,
  squadCount = YEONMU_SQUAD_COUNT,
  squadSize = YEONMU_SQUAD_SIZE,
  usedGeneralNames = new Set(),
  usedTacticNames = new Set(),
  prefilledSquads = [] // 티어덱이 이미 채워놓은 부대(그대로 유지, 이 함수는 나머지 부대만 만듦
) => {
  const pool = (generalNames || [])
    .filter((n) => !usedGeneralNames.has(n))
    .map((n) => allGenerals.find((g) => g.name === n))
    .filter(Boolean);
  const tacticsPool = (tacticNames || [])
    .filter((n) => !usedTacticNames.has(n))
    .map((n) => allTactics.find((t) => t.name === n))
    .filter(Boolean);

  const remainingSquadCount = Math.max(0, squadCount - prefilledSquads.length);

  const byRole = {};
  pool.forEach((g) => {
    const role = ROLE_GROUP_MAP[g.preferred_tactic_type] || '기타';
    if (!byRole[role]) byRole[role] = [];
    byRole[role].push(g);
  });

  const squads = Array.from({ length: remainingSquadCount }, () => []);
  const used = new Set();

  ROLE_PRIORITY.concat(['기타']).forEach((role) => {
    (byRole[role] || []).forEach((g) => {
      if (used.has(g.name)) return;
      let targetIdx = -1;
      let bestScore = Infinity;
      squads.forEach((sq, si) => {
        if (sq.length >= squadSize) return;
        const hasRole = sq.some((m) => (ROLE_GROUP_MAP[m.preferred_tactic_type] || '기타') === role);
        const sameFactionCount = sq.filter((m) => m.faction && m.faction === g.faction).length;
        // 인원 적은 부대 우선, 같은 역할이 이미 있으면 페널티, 같은 세력이 있으면 약간 유리(세력 보너스)
        const s = sq.length * 10 + (hasRole ? 5 : 0) - sameFactionCount;
        if (s < bestScore) { bestScore = s; targetIdx = si; }
      });
      if (targetIdx >= 0) {
        squads[targetIdx].push(g);
        used.add(g.name);
      }
    });
  });

  const bench = pool.filter((g) => !used.has(g.name));
  const squadGenerals = squads.flat();

  const pairs = [];
  squadGenerals.forEach((g) => {
    tacticsPool.forEach((t) => {
      const fit = scoreTacticForGeneral(t, g);
      pairs.push({ generalName: g.name, tacticName: t.name, ...fit });
    });
  });
  pairs.sort((a, b) => b.score - a.score);

  const tacticCount = {};
  const tacticUsed = new Set();
  const assignedTactics = {};
  squadGenerals.forEach((g) => { assignedTactics[g.name] = []; tacticCount[g.name] = 0; });

  pairs.forEach((p) => {
    if (tacticCount[p.generalName] >= 2) return;
    if (tacticUsed.has(p.tacticName)) return;
    assignedTactics[p.generalName].push({ name: p.tacticName, score: p.score, reasons: p.reasons, typeMatched: p.typeMatched });
    tacticCount[p.generalName] += 1;
    tacticUsed.add(p.tacticName);
  });

  const autoDecks = squads.map((sq, i) => ({
    squadNum: prefilledSquads.length + i + 1,
    heroes: sq.map((g) => ({ general: g, tactics: assignedTactics[g.name] || [] })),
    source: 'auto',
  }));

  const decks = [...prefilledSquads, ...autoDecks];

  const leftoverTactics = tacticsPool.filter((t) => !tacticUsed.has(t.name));

  return { decks, bench, leftoverTactics };
};

// 🆕 창고(+지원) 풀 기준, 완전 매칭(장수 3명 전원 보유)되는 티어덱을 티어 점수(parseTierScore) 높은 순으로
// 최대 squadCount개까지, 장수가 서로 겹치지 않게 선점 배치한다. 전법도 티어덱이 제안한 원본 조합 그대로 사용.
const pickYeonmuTierSquads = (tierDecks, generalPool, tacticPool, allTactics, squadCount = YEONMU_SQUAD_COUNT) => {
  const available = new Set(generalPool);
  const sorted = [...(tierDecks || [])]
    .map((deck) => ({ deck, match: scoreTierDeckMatch(deck, generalPool, tacticPool) }))
    .filter((d) => d.match.isFullGeneralMatch)
    .sort((a, b) => parseTierScoreLocal(b.deck.tier_name) - parseTierScoreLocal(a.deck.tier_name));

  const squads = [];
  const usedGeneralNames = new Set();
  const usedTacticNames = new Set();

  for (const { deck, match } of sorted) {
    if (squads.length >= squadCount) break;
    // 이미 다른 티어덱에 쓰인 장수와 겹치면 스킵(장수 중복 방지)
    if (match.deckGenNames.some((n) => usedGeneralNames.has(n))) continue;

    const heroes = match.setup.map((h) => {
      const tactics = h.main_tactics
        .filter((name) => name && name !== '전법 정보 없음')
        .map((name) => {
          const tacticData = allTactics.find((t) => t.name === name);
          return { name, score: 100, reasons: ['티어덱 검증 조합'], typeMatched: true, grade: tacticData?.grade };
        });
      tactics.forEach((t) => usedTacticNames.add(t.name));
      const generalData = h.general_name; // 이름만 필요, 실제 general 객체는 아래서 채움
      return { generalName: h.general_name, tactics };
    });

    heroes.forEach((h) => usedGeneralNames.add(h.generalName));

    squads.push({
      squadNum: squads.length + 1,
      tierDeckName: deck.deck_name || deck.name,
      tierName: deck.tier_name,
      matchPercent: match.percent,
      heroes,
      source: 'tier_deck',
    });
  }

  return { squads, usedGeneralNames, usedTacticNames };
};

// tierSquadMatcher.js의 parseTierScore와 동일 로직(연무탭 내부용 사본 — import 경로가 다를 수 있어 안전하게 로컬 정의)
function parseTierScoreLocal(tierName) {
  if (!tierName) return -1;
  const match = String(tierName).match(/T(\d)([+-]?)/);
  if (!match) return -1;
  const num = parseInt(match[1], 10);
  const modifier = match[2] === '+' ? 0.3 : match[2] === '-' ? -0.3 : 0;
  return (10 - num) + modifier;
}


// 🆕 사용자가 직접 부대(3명) 구성을 수정했을 때, 그 조합이 연무대회 기준으로 얼마나 괜찮은지 점수화.
// PDF(연무대회(1) 기본 로직 설명 / 연무대회2:무장 선택)에 나온 기준을 그대로 반영:
//  - 전열 탱커 유무가 매우 중요
//  - 단일 딜러보다 더블 코어(딜러 2명) 구성이 유리 (전투 템포가 느려짐)
//  - 확률형(발동 편차 큰) 무장은 안정성이 떨어져 페널티
//  - 병법/장비 보너스가 없어 전법의 "고정 수치 피해"가 "퍼센트 피해 증가"보다 유리
//  - 전법이 무장 타입과 실제로 궁합이 맞는지(typeMatched)도 반영
const scoreYeonmuSquadComposition = (heroes) => {
  if (!heroes || heroes.length === 0) return { score: 0, reasons: ['부대가 비어있음'] };

  let score = 50;
  const reasons = [];

  const roles = heroes.map((h) => ROLE_GROUP_MAP[h.general?.preferred_tactic_type] || '기타');
  const roleCounts = roles.reduce((m, r) => { m[r] = (m[r] || 0) + 1; return m; }, {});

  // 1. 전열 탱커 유무
  if (roleCounts['탱'] >= 1) {
    score += 15;
    reasons.push('전열 탱커 보유 (생존력 확보)');
  } else {
    score -= 20;
    reasons.push('⚠️ 전열 탱커 없음 — 연무는 전열 생존이 핵심');
  }

  // 2. 더블 코어 딜러 구성
  const dealerCount = roleCounts['딜'] || 0;
  if (dealerCount >= 2) {
    score += 15;
    reasons.push('더블 코어 딜러 구성 (느린 전투 템포에 유리)');
  } else if (dealerCount === 1) {
    score -= 10;
    reasons.push('단일 딜러 — 연무는 전투가 길어져 코어 1명으론 부족');
  } else {
    score -= 15;
    reasons.push('⚠️ 딜러 없음 — 딜 캐리 부재');
  }

  // 3. 힐/버프 지원
  if (roleCounts['힐']) {
    score += 8;
    reasons.push('힐러 포함 (병력 손실 방지)');
  }

  // 4. 확률형(불안정) 무장 페널티
  const volatileMembers = heroes.filter((h) => YEONMU_VOLATILE_GENERALS.includes(h.general?.name));
  if (volatileMembers.length > 0) {
    score -= volatileMembers.length * 12;
    reasons.push(`⚠️ 확률형 무장 포함(${volatileMembers.map((h) => h.general.name).join(', ')}) — 안정성 저하`);
  }

  // 5. 전법 타입 매칭률 + 고정 수치 피해 전법 가산
  const allTactics = heroes.flatMap((h) => h.tactics || []);
  if (allTactics.length > 0) {
    const matchedCount = allTactics.filter((t) => t.typeMatched).length;
    const matchRatio = matchedCount / allTactics.length;
    score += Math.round(matchRatio * 15);
    if (matchRatio < 0.5) reasons.push('전법-무장 궁합 낮음 (타입 불일치 다수)');

    const fixedDamageCount = allTactics.filter((t) => (t.reasons || []).some((r) => r.includes('고정 피해'))).length;
    if (fixedDamageCount > 0) {
      score += fixedDamageCount * 5;
      reasons.push('고정 수치 피해 전법 보유 (연무 유리)');
    }
  }

  return { score: Math.max(0, Math.min(100, Math.round(score))), reasons };
};

// 🆕 이미지 없이 텍스트 위주로 표시하는 선택 카드
// (보유 여부 grayscale 없음 — 연무대회 창고는 보유 무관하게 전체 풀에서 선택)
function SelectableCard({ name, subLabel, isSelected, onClick, disabled }) {
  return (
    <div
      onClick={disabled ? undefined : onClick}
      style={{
        position: 'relative',
        borderRadius: '8px',
        background: SCROLL.paperMid,
        border: `1px solid ${isSelected ? SCROLL.gold : SCROLL.headerBorder}`,
        padding: '10px 8px',
        textAlign: 'center',
        cursor: disabled ? 'not-allowed' : 'pointer',
        opacity: disabled && !isSelected ? 0.4 : 1,
      }}
    >
      <p style={{ margin: 0, fontSize: '12px', color: SCROLL.ink, fontWeight: 600, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
        {name}
      </p>
      {subLabel && (
        <p style={{ margin: '3px 0 0', fontSize: '10px', color: SCROLL.inkFaint, fontFamily: SCROLL.mono }}>{subLabel}</p>
      )}
      {isSelected && (
        <div style={{
          position: 'absolute', top: '4px', right: '4px', width: '14px', height: '14px',
          borderRadius: '50%', background: SCROLL.gold, display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontSize: '9px', color: SCROLL.paperLight, fontWeight: 700,
        }}>✓</div>
      )}
    </div>
  );
}

export default function YeonmuTab() {
  const { generals = [], tactics = [], tierDecks = [], selectedGenerals = [], selectedTactics = [], connections = [] } = useDeckAssets();
  const { warehouse, setWarehouse, isReady, resetWarehouse } = useYeonmuStorage();
  const [step, setStep] = useState('generals');

  // 🆕 텍스트 검색 및 진영 필터 state
  const [generalSearch, setGeneralSearch] = useState('');
  const [tacticSearch, setTacticSearch] = useState('');
  const [factionFilter, setFactionFilter] = useState('전체');

  const toggleGeneral = (name) => {
    setWarehouse((prev) => {
      const exists = prev.generals.includes(name);
      if (exists) {
        return { ...prev, generals: prev.generals.filter((n) => n !== name) };
      }
      if (prev.generals.length >= WAREHOUSE_LIMITS.generals) return prev;
      return { ...prev, generals: [...prev.generals, name] };
    });
  };

  const toggleTactic = (name) => {
    setWarehouse((prev) => {
      const exists = prev.tactics.includes(name);
      if (exists) {
        return { ...prev, tactics: prev.tactics.filter((n) => n !== name) };
      }
      if (prev.tactics.length >= WAREHOUSE_LIMITS.tactics) return prev;
      return { ...prev, tactics: [...prev.tactics, name] };
    });
  };

  // 🆕 진영 필터 + 검색어를 함께 적용한 장수 목록 (1단계)
  const filteredGenerals = useMemo(() => {
    let list = generals;
    if (factionFilter !== '전체') {
      list = list.filter((g) => g.faction === factionFilter);
    }
    if (generalSearch.trim()) {
      const q = generalSearch.trim().toLowerCase();
      list = list.filter((g) => g.name?.toLowerCase().includes(q));
    }
    return list;
  }, [generals, factionFilter, generalSearch]);

  // 🆕 검색어를 적용한 전법 목록 (2단계)
  const filteredTactics = useMemo(() => {
    if (!tacticSearch.trim()) return tactics;
    const q = tacticSearch.trim().toLowerCase();
    return tactics.filter((t) => t.name?.toLowerCase().includes(q));
  }, [tactics, tacticSearch]);

  // 🆕 이름을 입력하고 Enter를 누르면 바로 창고에 추가 (정확히 일치하는 이름 우선, 없으면 필터링된 첫 결과)
  const handleGeneralSearchKeyDown = (e) => {
    if (e.key !== 'Enter') return;
    const q = generalSearch.trim().toLowerCase();
    if (!q) return;
    const exact = generals.find((g) => g.name?.toLowerCase() === q);
    const target = exact || filteredGenerals[0];
    if (target) {
      toggleGeneral(target.name);
      setGeneralSearch('');
    }
  };

  const handleTacticSearchKeyDown = (e) => {
    if (e.key !== 'Enter') return;
    const q = tacticSearch.trim().toLowerCase();
    if (!q) return;
    const exact = tactics.find((t) => t.name?.toLowerCase() === q);
    const target = exact || filteredTactics[0];
    if (target) {
      toggleTactic(target.name);
      setTacticSearch('');
    }
  };

  // 3단계 후보: 창고 단계와 달리 "보유한" 장수/전법 중, 이미 창고에 있는 이름은 제외
  const supportGeneralCandidates = useMemo(() => {
    return generals.filter(
      (g) => selectedGenerals.includes(g.id) && !warehouse.generals.includes(g.name)
    );
  }, [generals, selectedGenerals, warehouse.generals]);

  const supportTacticCandidates = useMemo(() => {
    return tactics.filter(
      (t) => selectedTactics.includes(t.id) && !warehouse.tactics.includes(t.name)
    );
  }, [tactics, selectedTactics, warehouse.tactics]);

  // 🆕 지원 무장/전법 후보를 추천 점수 내림차순으로 정렬 (창고 구성과의 시너지 기반)
  const scoredSupportGeneralCandidates = useMemo(() => {
    return supportGeneralCandidates
      .map((g) => ({ ...g, ...scoreSupportGeneral(g, warehouse.generals, generals, connections) }))
      .sort((a, b) => b.score - a.score);
  }, [supportGeneralCandidates, warehouse.generals, generals, connections]);

  const scoredSupportTacticCandidates = useMemo(() => {
    return supportTacticCandidates
      .map((t) => ({ ...t, ...scoreSupportTactic(t, warehouse.tactics, tactics) }))
      .sort((a, b) => b.score - a.score);
  }, [supportTacticCandidates, warehouse.tactics, tactics]);

  // 🆕 4단계 추천덱: 창고 장수 10명 + 지원 장수 1명(선택 시), 창고 전법 20개 + 지원 전법 2개(선택 시) 풀만으로
  // 3개 부대를 자동 편성. 타입이 안 맞는 전법이라도 반드시 배정되도록 buildRecommendedYeonmuSquads에서 처리.
  const deckGeneralPool = useMemo(() => {
    return warehouse.supportGeneral ? [...warehouse.generals, warehouse.supportGeneral] : [...warehouse.generals];
  }, [warehouse.generals, warehouse.supportGeneral]);

  const deckTacticPool = useMemo(() => {
    return [...warehouse.tactics, ...warehouse.supportTactics];
  }, [warehouse.tactics, warehouse.supportTactics]);

  // 🐛 버그 수정: pickYeonmuTierSquads가 정의만 되어있고 실제로 호출되지 않아, 완전 매칭된 티어덱이
  // "매칭됨" 표시만 되고 실제 3개 부대 편성에는 전혀 반영되지 않던 문제. 이제 완전 매칭 티어덱을
  // 최우선으로 선점 배치하고, 남은 자리만 기존 그리디 로직으로 채운다.
  const { decks: recommendedDecks, bench: recommendedBench, leftoverTactics } = useMemo(() => {
    const tierResult = pickYeonmuTierSquads(tierDecks, deckGeneralPool, deckTacticPool, tactics, YEONMU_SQUAD_COUNT);

    const prefilledSquads = tierResult.squads.map((sq) => ({
      squadNum: sq.squadNum,
      heroes: sq.heroes
        .map((h) => ({
          general: generals.find((g) => g.name === h.generalName),
          tactics: h.tactics,
        }))
        .filter((h) => h.general),
      source: 'tier_deck',
      tierDeckName: sq.tierDeckName,
      tierName: sq.tierName,
      matchPercent: sq.matchPercent,
    }));

    return buildRecommendedYeonmuSquads(
      deckGeneralPool,
      deckTacticPool,
      generals,
      tactics,
      YEONMU_SQUAD_COUNT,
      YEONMU_SQUAD_SIZE,
      tierResult.usedGeneralNames,
      tierResult.usedTacticNames,
      prefilledSquads
    );
  }, [tierDecks, deckGeneralPool, deckTacticPool, generals, tactics]);

  // 🆕 사용자가 4단계에서 직접 수정할 수 있는 편집 가능한 편성본.
  // 창고 구성(deckGeneralPool/deckTacticPool)이 바뀌어 recommendedDecks가 새로 계산되면 편집본도 초기화된다.
  const [customDecks, setCustomDecks] = useState([]);
  const [selectedHero, setSelectedHero] = useState(null); // { squadIdx, heroIdx }

  useEffect(() => {
    setCustomDecks(recommendedDecks);
    setSelectedHero(null);
  }, [recommendedDecks]);

  // 부대 슬롯(장수+전법 세트) 두 개를 서로 맞바꾼다 — 사용자가 직접 편성을 바꿔볼 수 있게 함
  const handleHeroSlotClick = (squadIdx, heroIdx) => {
    if (!selectedHero) {
      setSelectedHero({ squadIdx, heroIdx });
      return;
    }
    if (selectedHero.squadIdx === squadIdx && selectedHero.heroIdx === heroIdx) {
      setSelectedHero(null);
      return;
    }
    setCustomDecks((prev) => {
      const next = prev.map((d) => ({ ...d, heroes: [...d.heroes] }));
      const a = next[selectedHero.squadIdx]?.heroes[selectedHero.heroIdx];
      const b = next[squadIdx]?.heroes[heroIdx];
      if (!a || !b) return prev;
      next[selectedHero.squadIdx].heroes[selectedHero.heroIdx] = b;
      next[squadIdx].heroes[heroIdx] = a;
      return next;
    });
    setSelectedHero(null);
  };

  const resetCustomDecks = () => {
    setCustomDecks(recommendedDecks);
    setSelectedHero(null);
  };

  // 🆕 각 부대(편집본 기준)의 PDF 로직 기반 점수
  const customDeckScores = useMemo(
    () => customDecks.map((d) => scoreYeonmuSquadComposition(d.heroes)),
    [customDecks]
  );

  const isDecksEdited = useMemo(() => {
    if (customDecks.length !== recommendedDecks.length) return true;
    return customDecks.some((d, i) =>
      d.heroes.some((h, hi) => h.general?.name !== recommendedDecks[i]?.heroes[hi]?.general?.name)
    );
  }, [customDecks, recommendedDecks]);

  // 🆕 창고(+지원) 장수/전법 풀 기준으로 tier_decks 전체를 매칭 점수순 정렬.
  // scoreTierDeckMatch는 MatchesTab.js/SquadsTab.js와 동일 로직(장수 60% + 전법 40% 가중치)을 공용으로 쓰는 유틸(data/tierDeckMatch.js).
  // 장수 3명이 모두 창고 풀에 있는 "완전 매칭" 덱을 최우선으로, 그 외에는 매칭률(percent) 내림차순으로 정렬한다.
  const matchedTierDecks = useMemo(() => {
    if (!tierDecks.length) return [];
    return tierDecks
      .map((deck) => ({ deck, match: scoreTierDeckMatch(deck, deckGeneralPool, deckTacticPool) }))
      .filter((d) => d.match.totalGenCount > 0 && d.match.matchedGenCount > 0)
      .sort((a, b) => {
        if (a.match.isFullGeneralMatch !== b.match.isFullGeneralMatch) {
          return a.match.isFullGeneralMatch ? -1 : 1;
        }
        return b.match.percent - a.match.percent;
      });
  }, [tierDecks, deckGeneralPool, deckTacticPool]);

  const fullyMatchedTierDecks = useMemo(
    () => matchedTierDecks.filter((d) => d.match.isFullGeneralMatch),
    [matchedTierDecks]
  );

  const neededGenerals = YEONMU_SQUAD_COUNT * YEONMU_SQUAD_SIZE;

  if (!isReady) return null;

  return (
    <div style={{ background: SCROLL.bg, minHeight: '100%', padding: '16px' }}>
      <div style={{ maxWidth: '480px', margin: '0 auto' }}>

        <div style={{ padding: '4px 0 14px' }}>
          <p style={{ fontSize: '11px', color: SCROLL.gold, letterSpacing: '0.05em', margin: '0 0 4px', fontFamily: SCROLL.mono }}>
            SANGUOZHI · YEONMU
          </p>
          <h2 style={{ margin: 0, fontSize: '17px', color: SCROLL.ink }}>창고 입력</h2>
        </div>

        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '14px' }}>
          <div style={{ display: 'flex', gap: '6px' }}>
            {STEPS.map((s) => (
              <button
                key={s.key}
                onClick={() => setStep(s.key)}
                style={{
                  fontSize: '11px', padding: '5px 10px', borderRadius: '4px', border: `0.5px solid ${SCROLL.border}`,
                  background: step === s.key ? SCROLL.gold : 'transparent',
                  color: step === s.key ? SCROLL.paperLight : SCROLL.inkFaint,
                  fontWeight: step === s.key ? 600 : 400, cursor: 'pointer',
                }}
              >
                {s.label}
              </button>
            ))}
          </div>
          <button
            onClick={() => { if (confirm('이번 주 창고 데이터를 모두 지울까요?')) resetWarehouse(); }}
            style={{ fontSize: '12px', border: `0.5px solid ${SCROLL.border}`, background: 'transparent', color: SCROLL.inkFaint, borderRadius: '6px', padding: '5px 10px' }}
          >
            초기화
          </button>
        </div>

        {step === 'generals' && (
          <>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: '10px' }}>
              <span style={{ fontSize: '12px', color: SCROLL.inkFaint }}>무장 10명 선택 (시작 4 + 드래프트 6)</span>
              <span style={{ fontSize: '12px', color: SCROLL.gold, fontFamily: SCROLL.mono }}>
                {warehouse.generals.length} / {WAREHOUSE_LIMITS.generals}
              </span>
            </div>

            {/* 🆕 진영 필터 */}
            <div style={{ display: 'flex', gap: '6px', marginBottom: '10px' }}>
              {FACTIONS.map((f) => (
                <button
                  key={f}
                  onClick={() => setFactionFilter(f)}
                  style={{
                    fontSize: '11px',
                    padding: '5px 12px',
                    borderRadius: '4px',
                    border: `0.5px solid ${SCROLL.border}`,
                    background: factionFilter === f ? SCROLL.gold : 'transparent',
                    color: factionFilter === f ? SCROLL.paperLight : SCROLL.inkFaint,
                    fontWeight: factionFilter === f ? 600 : 400,
                    cursor: 'pointer',
                  }}
                >
                  {f}
                </button>
              ))}
            </div>

            {/* 🆕 텍스트 검색 (이름 입력 후 Enter로 바로 추가) */}
            <input
              type="text"
              value={generalSearch}
              onChange={(e) => setGeneralSearch(e.target.value)}
              onKeyDown={handleGeneralSearchKeyDown}
              placeholder="장수 이름 입력 후 Enter로 추가"
              style={{
                width: '100%',
                boxSizing: 'border-box',
                padding: '8px 10px',
                marginBottom: '10px',
                fontSize: '12px',
                borderRadius: '6px',
                border: `0.5px solid ${SCROLL.border}`,
                background: SCROLL.paperMid,
                color: SCROLL.ink,
                outline: 'none',
              }}
            />

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '8px' }}>
              {filteredGenerals.map((g) => (
                <SelectableCard
                  key={g.id}
                  name={g.name}
                  subLabel={`${g.faction || ''}${g.troop_type ? ' · ' + g.troop_type : ''}`}
                  isSelected={warehouse.generals.includes(g.name)}
                  disabled={warehouse.generals.length >= WAREHOUSE_LIMITS.generals && !warehouse.generals.includes(g.name)}
                  onClick={() => toggleGeneral(g.name)}
                />
              ))}
            </div>
          </>
        )}

        {step === 'tactics' && (
          <>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: '10px' }}>
              <span style={{ fontSize: '12px', color: SCROLL.inkFaint }}>전법 20개 선택 (시작 8 + 드래프트 12)</span>
              <span style={{ fontSize: '12px', color: SCROLL.gold, fontFamily: SCROLL.mono }}>
                {warehouse.tactics.length} / {WAREHOUSE_LIMITS.tactics}
              </span>
            </div>

            {/* 🆕 텍스트 검색 (이름 입력 후 Enter로 바로 추가) */}
            <input
              type="text"
              value={tacticSearch}
              onChange={(e) => setTacticSearch(e.target.value)}
              onKeyDown={handleTacticSearchKeyDown}
              placeholder="전법 이름 입력 후 Enter로 추가"
              style={{
                width: '100%',
                boxSizing: 'border-box',
                padding: '8px 10px',
                marginBottom: '10px',
                fontSize: '12px',
                borderRadius: '6px',
                border: `0.5px solid ${SCROLL.border}`,
                background: SCROLL.paperMid,
                color: SCROLL.ink,
                outline: 'none',
              }}
            />

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '8px' }}>
              {filteredTactics.map((t) => (
                <SelectableCard
                  key={t.id}
                  name={t.name}
                  subLabel={t.grade || ''}
                  isSelected={warehouse.tactics.includes(t.name)}
                  disabled={warehouse.tactics.length >= WAREHOUSE_LIMITS.tactics && !warehouse.tactics.includes(t.name)}
                  onClick={() => toggleTactic(t.name)}
                />
              ))}
            </div>
          </>
        )}

        {step === 'support' && (
          <>
            {/* 🆕 지원 무장 1명 / 전법 3개 후보를 창고 구성과의 시너지 점수(S/A/B/C) 내림차순으로 표시.
                scoredSupportGeneralCandidates / scoredSupportTacticCandidates 는 "보유 + 창고와 중복 제외" 필터에
                score(0~100)와 reasons(추천 이유 배열)를 더해 점수 높은 순으로 정렬한 목록. */}
            <div style={{ marginBottom: '18px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: '8px' }}>
                <span style={{ fontSize: '12px', color: SCROLL.inkFaint }}>지원 무장 1명 (보유 목록 중 · 추천순)</span>
                <span style={{ fontSize: '12px', color: SCROLL.gold, fontFamily: SCROLL.mono }}>
                  {warehouse.supportGeneral ? 1 : 0} / 1
                </span>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
                {scoredSupportGeneralCandidates.map((g) => {
                  const isSel = warehouse.supportGeneral === g.name;
                  const tier = getTierBadge(g.score);
                  return (
                    <div
                      key={g.id}
                      onClick={() => setWarehouse((prev) => ({
                        ...prev,
                        supportGeneral: prev.supportGeneral === g.name ? null : g.name,
                      }))}
                      style={{
                        display: 'flex', alignItems: 'center', gap: '10px', padding: '9px 10px', borderRadius: '8px', cursor: 'pointer',
                        background: isSel ? SCROLL.greenBg : SCROLL.paperMid,
                        borderLeft: isSel ? `2px solid ${SCROLL.green}` : '2px solid transparent',
                      }}
                    >
                      <div style={{ flex: 1, minWidth: 0 }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                          <p style={{ margin: 0, fontSize: '12px', color: SCROLL.ink, fontWeight: 600 }}>{g.name}</p>
                          <span style={{
                            fontSize: '10px', fontWeight: 700, fontFamily: SCROLL.mono, color: tier.color,
                            border: `0.5px solid ${tier.color}`, borderRadius: '4px', padding: '0 5px'
                          }}>
                            {tier.label} · {g.score}
                          </span>
                        </div>
                        {g.reasons.length > 0 && (
                          <p style={{ margin: '3px 0 0', fontSize: '10px', color: SCROLL.inkFaint }}>
                            {g.reasons.join(' · ')}
                          </p>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            <div>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: '8px' }}>
                <span style={{ fontSize: '12px', color: SCROLL.inkFaint }}>지원 전법 3개 (보유 목록 중 · 추천순)</span>
                <span style={{ fontSize: '12px', color: SCROLL.gold, fontFamily: SCROLL.mono }}>
                  {warehouse.supportTactics.length} / {WAREHOUSE_LIMITS.supportTactics}
                </span>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
                {scoredSupportTacticCandidates.map((t) => {
                  const isSel = warehouse.supportTactics.includes(t.name);
                  const isFull = warehouse.supportTactics.length >= WAREHOUSE_LIMITS.supportTactics;
                  const tier = getTierBadge(t.score);
                  const gradeBadge = getTacticGradeBadge(t.grade);
                  return (
                    <div
                      key={t.id}
                      onClick={() => {
                        if (isFull && !isSel) return;
                        setWarehouse((prev) => ({
                          ...prev,
                          supportTactics: isSel
                            ? prev.supportTactics.filter((n) => n !== t.name)
                            : [...prev.supportTactics, t.name],
                        }));
                      }}
                      style={{
                        display: 'flex', alignItems: 'center', gap: '10px', padding: '9px 10px', borderRadius: '8px',
                        cursor: isFull && !isSel ? 'not-allowed' : 'pointer',
                        opacity: isFull && !isSel ? 0.4 : 1,
                        background: isSel ? SCROLL.greenBg : SCROLL.paperMid,
                        borderLeft: isSel ? `2px solid ${SCROLL.green}` : '2px solid transparent',
                      }}
                    >
                      <div style={{ flex: 1, minWidth: 0 }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                          <p style={{ margin: 0, fontSize: '12px', color: SCROLL.ink, fontWeight: 600 }}>
                            {gradeBadge && `${gradeBadge} `}{t.name}
                          </p>
                          <span style={{
                            fontSize: '10px', fontWeight: 700, fontFamily: SCROLL.mono, color: tier.color,
                            border: `0.5px solid ${tier.color}`, borderRadius: '4px', padding: '0 5px'
                          }}>
                            {tier.label} · {t.score}
                          </span>
                        </div>
                        {t.reasons.length > 0 && (
                          <p style={{ margin: '3px 0 0', fontSize: '10px', color: SCROLL.inkFaint }}>
                            {t.reasons.join(' · ')}
                          </p>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </>
        )}

        {step === 'decks' && (
          <>
            {/* 🆕 창고(+지원) 풀 기준 티어덱 매칭 — SquadsTab/MatchesTab과 동일한 scoreTierDeckMatch 유틸 사용.
                장수 3명이 전부 창고 풀 안에 있는 "완전 매칭" 덱을 최우선으로 보여주고,
                그 외 부분 매칭 덱은 매칭률 상위 몇 개만 참고용으로 노출한다. */}
            {matchedTierDecks.length > 0 && (
              <div style={{ marginBottom: '16px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: '8px' }}>
                  <span style={{ fontSize: '12px', color: SCROLL.inkFaint }}>
                    티어덱 매칭 {fullyMatchedTierDecks.length > 0 ? `(완전 매칭 ${fullyMatchedTierDecks.length}개)` : '(참고용 부분 매칭)'}
                  </span>
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                  {(fullyMatchedTierDecks.length > 0 ? fullyMatchedTierDecks : matchedTierDecks.slice(0, 5)).map(({ deck, match }) => {
                    const tier = getTierBadge(match.percent);
                    return (
                      <div
                        key={deck.id}
                        style={{
                          padding: '10px 12px', borderRadius: '10px',
                          background: match.isFullGeneralMatch ? SCROLL.greenBg : SCROLL.paperMid,
                          border: `0.5px solid ${match.isFullGeneralMatch ? SCROLL.green : SCROLL.headerBorder}`,
                        }}
                      >
                        <div style={{ display: 'flex', alignItems: 'center', gap: '6px', marginBottom: '4px' }}>
                          <p style={{ margin: 0, fontSize: '13px', color: SCROLL.ink, fontWeight: 700 }}>
                            {deck.deck_name || deck.name}
                          </p>
                          <span style={{
                            fontSize: '10px', fontWeight: 700, fontFamily: SCROLL.mono, color: tier.color,
                            border: `0.5px solid ${tier.color}`, borderRadius: '4px', padding: '0 5px'
                          }}>
                            {tier.label} · {match.percent}%
                          </span>
                          {match.isFullGeneralMatch && (
                            <span style={{ fontSize: '10px', color: SCROLL.green, fontFamily: SCROLL.mono }}>✓ 장수 완전 매칭</span>
                          )}
                        </div>
                        <p style={{ margin: 0, fontSize: '11px', color: SCROLL.inkFaint }}>
                          장수 {match.matchedGenCount}/{match.totalGenCount} · 전법 {match.matchedTactCount}/{match.totalTactCount} — {match.deckGenNames.join(', ')}
                        </p>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* 🆕 창고(+지원) 풀만으로 자동 편성한 3개 부대 추천안.
                타입이 안 맞는 전법이라도(예: 책략 장수에 병기 전법) 빈 슬롯 없이 반드시 2개씩 채우는 것을 우선함 —
                ⚠️ 배지가 붙은 전법은 궁합이 이상적이지 않으니 상황 봐서 직접 바꿔써도 됨. */}
            <div style={{ marginBottom: '12px' }}>
              <span style={{ fontSize: '12px', color: SCROLL.inkFaint }}>
                창고 장수 {warehouse.generals.length}명{warehouse.supportGeneral ? ' + 지원 1명' : ''} · 창고 전법 {warehouse.tactics.length}개{warehouse.supportTactics.length > 0 ? ` + 지원 ${warehouse.supportTactics.length}개` : ''} 풀로 자동 편성
              </span>
              {deckGeneralPool.length < neededGenerals && (
                <p style={{ margin: '6px 0 0', fontSize: '11px', color: SCROLL.gold }}>
                  ⚠️ 장수가 {deckGeneralPool.length}명뿐이라 부대를 다 채우지 못했어요. 3개 부대(9명)를 다 채우려면 {neededGenerals}명이 필요해요.
                </p>
              )}
            </div>

            {/* 🆕 장수 카드를 클릭하면 선택되고, 다른 장수 카드를 한번 더 클릭하면 두 자리가 서로 맞바뀐다.
                직접 편성을 바꿔보면서 옆의 점수(S/A/B/C)가 어떻게 변하는지 바로 확인 가능 — PDF 기준(전열 탱커,
                더블 코어 딜러, 확률형 무장 회피, 고정 수치 피해 전법 우선) 그대로 반영한 scoreYeonmuSquadComposition 사용. */}
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px' }}>
              <span style={{ fontSize: '11px', color: SCROLL.inkFaint }}>
                {selectedHero ? '바꿔 넣을 다른 장수를 클릭하세요' : '장수를 클릭해 부대끼리 자리를 바꿔볼 수 있어요'}
              </span>
              {isDecksEdited && (
                <button
                  onClick={resetCustomDecks}
                  style={{ fontSize: '11px', border: `0.5px solid ${SCROLL.border}`, background: 'transparent', color: SCROLL.gold, borderRadius: '6px', padding: '4px 8px', cursor: 'pointer' }}
                >
                  초기 추천으로 되돌리기
                </button>
              )}
            </div>

            {customDecks.map((deck, dIdx) => {
              const squadScore = customDeckScores[dIdx] || { score: 0, reasons: [] };
              const scoreTier = getTierBadge(squadScore.score);
              return (
              <div key={deck.squadNum} style={{
                marginBottom: '14px', padding: '14px', borderRadius: '10px',
                background: SCROLL.paperMid, border: `0.5px solid ${SCROLL.headerBorder}`
              }}>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '10px' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <span style={{
                      fontSize: '12px', fontWeight: 700, color: SCROLL.gold,
                      fontFamily: SCROLL.mono, letterSpacing: '0.05em'
                    }}>
                      {deck.squadNum}군
                    </span>
                    {deck.source === 'tier_deck' && (
                      <span style={{ fontSize: '10px', color: SCROLL.green, border: `0.5px solid ${SCROLL.green}`, borderRadius: '4px', padding: '0 5px', fontFamily: SCROLL.mono }}>
                        ✓ 티어덱 «{deck.tierDeckName}» ({deck.tierName})
                      </span>
                    )}
                  </div>
                  <span style={{
                    fontSize: '10px', fontWeight: 700, fontFamily: SCROLL.mono, color: scoreTier.color,
                    border: `0.5px solid ${scoreTier.color}`, borderRadius: '4px', padding: '1px 6px'
                  }}>
                    {scoreTier.label} · {squadScore.score}점
                  </span>
                </div>

                {squadScore.reasons.length > 0 && (
                  <p style={{ margin: '0 0 10px', fontSize: '10px', color: SCROLL.inkFaint, lineHeight: 1.5 }}>
                    {squadScore.reasons.join(' · ')}
                  </p>
                )}

                <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                  {deck.heroes.map((hero, hIdx) => {
                    const roleLabel = ROLE_LABEL_MAP[hero.general.preferred_tactic_type] || hero.general.preferred_tactic_type || '';
                    const isSel = selectedHero && selectedHero.squadIdx === dIdx && selectedHero.heroIdx === hIdx;
                    return (
                      <div
                        key={hIdx}
                        onClick={() => handleHeroSlotClick(dIdx, hIdx)}
                        style={{
                          padding: '10px', borderRadius: '8px', background: isSel ? SCROLL.greenBg : SCROLL.bg,
                          border: `0.5px solid ${isSel ? SCROLL.green : SCROLL.border}`, cursor: 'pointer',
                        }}
                      >
                        <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '6px' }}>
                          <p style={{ margin: 0, fontSize: '12px', color: SCROLL.ink, fontWeight: 700 }}>
                            {hero.general.name}
                            {roleLabel && (
                              <span style={{ marginLeft: '6px', fontSize: '10px', color: SCROLL.inkFaint, fontFamily: SCROLL.mono, fontWeight: 400 }}>
                                [{roleLabel}]
                              </span>
                            )}
                            {YEONMU_VOLATILE_GENERALS.includes(hero.general.name) && (
                              <span style={{ marginLeft: '6px', fontSize: '9px', color: SCROLL.gold, border: `0.5px solid ${SCROLL.gold}`, borderRadius: '4px', padding: '0 4px' }}>
                                ⚠️ 확률형
                              </span>
                            )}
                          </p>
                        </div>
                        <div style={{ display: 'flex', flexDirection: 'column', gap: '4px', marginLeft: '0' }}>
                          {hero.tactics.length === 0 && (
                            <span style={{ fontSize: '10px', color: SCROLL.inkFaint }}>배정 가능한 전법 없음 (풀 소진)</span>
                          )}
                          {hero.tactics.map((t, tIdx) => {
                            const gradeBadge = getTacticGradeBadge(
                              tactics.find((tc) => tc.name?.trim() === t.name?.trim())?.grade
                            );
                            return (
                              <div key={tIdx} style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '11px' }}>
                                <span style={{ color: SCROLL.ink }}>
                                  {gradeBadge && `${gradeBadge} `}{t.name}
                                </span>
                                {!t.typeMatched && (
                                  <span style={{ fontSize: '9px', color: SCROLL.gold, border: `0.5px solid ${SCROLL.gold}`, borderRadius: '4px', padding: '0 4px' }}>
                                    ⚠️ 타입 불일치
                                  </span>
                                )}
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
              );
            })}

            {recommendedBench.length > 0 && (
              <div style={{ marginBottom: '14px', padding: '12px', borderRadius: '10px', background: SCROLL.paperMid, border: `0.5px dashed ${SCROLL.border}` }}>
                <div style={{ fontSize: '11px', color: SCROLL.inkFaint, marginBottom: '6px', fontFamily: SCROLL.mono }}>예비 (미출전)</div>
                <div style={{ fontSize: '12px', color: SCROLL.ink }}>
                  {recommendedBench.map((g) => g.name).join(', ')}
                </div>
              </div>
            )}

            {leftoverTactics.length > 0 && (
              <div style={{ padding: '12px', borderRadius: '10px', background: SCROLL.paperMid, border: `0.5px dashed ${SCROLL.border}` }}>
                <div style={{ fontSize: '11px', color: SCROLL.inkFaint, marginBottom: '6px', fontFamily: SCROLL.mono }}>미사용 전법</div>
                <div style={{ fontSize: '12px', color: SCROLL.ink }}>
                  {leftoverTactics.map((t) => t.name).join(', ')}
                </div>
              </div>
            )}
          </>
        )}

      </div>
    </div>
  );
}