// app/components/RouteMiniMap.js
'use client';

// steps: JeongcheolResultCard/page.js에서 넘어오는 배열. coord가 있는 항목만 그림.
// 실제 지도 축척이 아니라, 좌표들의 상대 위치만 정규화해서 보여주는 '대략적인' 미니맵입니다.
export default function RouteMiniMap({ steps, width = 560, height = 260 }) {
  const points = (steps || [])
    .map((s, i) => ({ ...s, order: i + 1 }))
    .filter((s) => s.coord && Number.isFinite(Number(s.coord.x)) && Number.isFinite(Number(s.coord.y)));

  if (points.length < 2) {
    return (
      <div
        style={{
          padding: '14px',
          textAlign: 'center',
          fontSize: '12px',
          color: '#8a6a2e',
          opacity: 0.75,
        }}
      >
        좌표가 등록된 성이 2개 이상이면 루트 미니맵이 표시됩니다.
      </div>
    );
  }

  const xs = points.map((p) => Number(p.coord.x));
  const ys = points.map((p) => Number(p.coord.y));
  const minX = Math.min(...xs);
  const maxX = Math.max(...xs);
  const minY = Math.min(...ys);
  const maxY = Math.max(...ys);

  const pad = 30;
  const spanX = maxX - minX || 1;
  const spanY = maxY - minY || 1;

  // 게임 내 좌표는 보통 위쪽일수록 Y가 작으므로, 화면상 위=작은 Y로 그대로 매핑
  const toSvg = (x, y) => {
    const px = pad + ((x - minX) / spanX) * (width - pad * 2);
    const py = pad + ((y - minY) / spanY) * (height - pad * 2);
    return [px, py];
  };

  const pathD = points
    .map((p, i) => {
      const [px, py] = toSvg(Number(p.coord.x), Number(p.coord.y));
      return `${i === 0 ? 'M' : 'L'} ${px.toFixed(1)} ${py.toFixed(1)}`;
    })
    .join(' ');

  return (
    <div style={{ width: '100%', overflow: 'hidden' }}>
      <svg width={width} height={height} viewBox={`0 0 ${width} ${height}`} style={{ display: 'block', margin: '0 auto' }}>
        <path d={pathD} fill="none" stroke="#9c2b2b" strokeWidth="2" strokeDasharray="6 4" opacity="0.8" />
        {points.map((p, i) => {
          const [px, py] = toSvg(Number(p.coord.x), Number(p.coord.y));
          return (
            <g key={p.id ?? i}>
              <circle cx={px} cy={py} r="10" fill="#f4e6c4" stroke="#9c2b2b" strokeWidth="2" />
              <text x={px} y={py + 4} textAnchor="middle" fontSize="11" fontWeight="700" fill="#7a1f18">
                {p.order}
              </text>
              <text x={px} y={py - 16} textAnchor="middle" fontSize="12" fontWeight="700" fill="#4a2f12">
                {p.name}
              </text>
            </g>
          );
        })}
      </svg>
      <p style={{ textAlign: 'center', fontSize: '11px', color: '#8a6a2e', opacity: 0.7, margin: '2px 0 0 0' }}>
        * 실제 축척이 아닌, 등록된 좌표 기준 대략적인 상대 위치입니다
      </p>
    </div>
  );
}